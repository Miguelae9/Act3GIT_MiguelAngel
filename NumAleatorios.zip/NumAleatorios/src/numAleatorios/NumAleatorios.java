package numAleatorios;

import java.util.Random;

public class NumAleatorios {
	
	public NumAleatorios() {
		
		Random random = new Random();
		int numero = 0;
		
		for(int i = 0; i < 20; i++) {
			numero = random.nextInt(10) + 1;
			System.out.println(numero);
		}	
	}	
}
